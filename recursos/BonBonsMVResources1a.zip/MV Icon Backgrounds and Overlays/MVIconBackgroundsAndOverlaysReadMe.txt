Credits:  Kadokawa and The Infamous Bon Bon.  Requires that you own a license for RPG Maker MV to use.
Terms:  Free to Use in Commercial and Non-commercial games with credit (Free game would be nice but not required)

These were derived from MV RTP:
	MVIconBackgrounds1 - Intended to be used with the Ace Icons I made.  They can also be used with any icons 26 x 26 
				or smaller without extending into the border, such as Avery's
	BookPagesAndTitle - I used these when recoloring my book icons (found in the MVTilesetIcons.png).  You simply edit
				the hue, colorize, or whatever and layer these on top so they still look like books.
	Sack[color] - These are the base sack colors I made.  Intended to be overlayed by the SackString[color].png files.
	SackString[color] - see Sack[color] above.

Contact:  http://forums.rpgmakerweb.com, you can send me a PM.  I don't change my name, so you should be able to find me
	or through my blog - Candy Coded Response - https://ccrgeek.wordpress.com/