Credits:  Kadokawa and The Infamous Bon Bon.  Requires that you own a license for RPG Maker MV to use.
Terms:  Free to Use in Commercial and Non-commercial games with credit (Free game would be nice but not required)

These were derived from MV RTP and includes some edits.

Contact:  http://forums.rpgmakerweb.com, you can send me a PM.  I don't change my name, so you should be able to find me
	or through my blog - Candy Coded Response - https://ccrgeek.wordpress.com/